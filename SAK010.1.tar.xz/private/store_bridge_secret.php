<?php
return ['encryption_key' => 'oVlru1HDMkZkj6aXLtJRTl5j3Wbque3Gc3vhm/afqlk='];
