<?php
/**
 * CHEATGAME reseller API configuration.
 * Keep this file outside public_html.
 */
return [
    'endpoint' => 'https://cheatgame.online/reseller_api.php',
    'api_key' => 'cgo_rsl_46b65366_1b1953ed48d163024773cb1ee1e12fe0303a4541495a72271f110d04e6ded4b1',
    'webhook_secret' => '0e2d01351d3f80b47a9e56dc5d0bcd6b8e9aeb6ec4f1f86f0b9a8b03de233f51',
    'allowed_server_ip' => '15.235.227.117',
    'connect_timeout' => 8,
    'request_timeout' => 25,
    // Keep storefront stock reasonably fresh without making every page view call
    // the supplier. The database lock ensures only one refresh runs per interval.
    'inventory_cache_ttl_seconds' => 30,

    // A checkout may reuse a snapshot fetched within the last few seconds. The
    // supplier order endpoint remains authoritative and all balance/order locks
    // still apply, so this removes a redundant network round-trip without
    // weakening duplicate-order or overspending protection.
    'inventory_purchase_max_age_seconds' => 5,
    // Required while Allowed Server IP is an IPv4 address.
    'force_ipv4' => true,

    // One copied configuration can safely serve both websites. The active
    // profile is selected from the database name suffix first, then the exact
    // HTTP host. Unknown sites fail closed and cannot submit API orders.
    'site_profiles' => [
        'SAK-010' => [
            'site_code' => 'SAK',
            'database_code' => '010',
            'database_suffix' => '_010',
            'hosts' => ['sakazuki.spwz.online'],
            'live_order_enabled' => true,
            'webhook_role' => 'hub',
        ],
        'ONL-005' => [
            'site_code' => 'ONL',
            'database_code' => '005',
            'database_suffix' => '_005',
            'hosts' => ['online.spwz.online'],
            'live_order_enabled' => true,
            'webhook_role' => 'receiver',
        ],
    ],

    // CHEATGAME sends to this public URL. The hub verifies and de-duplicates
    // the event, then processes SAK locally or forwards ONL to its own receiver.
    'webhook_public_url' => 'https://sakazuki.spwz.online/webhook_cheatgame.php',
    'webhook_routes' => [
        'SAK-010' => 'local',
        'ONL-005' => 'https://online.spwz.online/webhook_cheatgame.php',
    ],
    'webhook_forward_connect_timeout' => 5,
    'webhook_forward_timeout' => 15,
];
