<?php
/**
 * xChetos HWID reset integration.
 *
 * Keep this file outside public_html and restrict its permissions to 600 or 640.
 * The browser and reseller accounts must never receive these credentials.
 */
return [
    'enabled' => true,
    'base_url' => 'https://xchetos.online',

    // Fill the xChetos reseller login here, or set the environment variables
    // XCHETOS_USERNAME and XCHETOS_PASSWORD instead.
    'username' => 'om_shop',
    'password' => 'om_shop_123',

    // Only keys beginning with one of these prefixes will be sent to xChetos.
    // The captured reseller account uses keys beginning with "22-".
    'allowed_key_prefixes' => ['22-'],

    // Prevent accidental double submits for the same key.
    'cooldown_seconds' => 60,
    // Unknown/timeout responses are held longer because the provider may have
    // completed the reset even when its response did not reach this server.
    'unknown_cooldown_seconds' => 300,

    // Reseller policy. The daily allowance uses a rolling 24-hour window.
    // Administrators can adjust these values from the Key Reset admin page.
    'reseller_daily_limit' => 100,
    'reseller_key_limit' => 2,
    'daily_window_seconds' => 86400,

    // Short burst guard. It is separate from the 24-hour allowance.
    'burst_max_attempts' => 12,
    'burst_window_seconds' => 60,

    // Backward-compatible aliases retained for older deployments.
    'max_attempts' => 100,
    'rate_window_seconds' => 86400,

    // Inventory verification now advances by the number of rows actually
    // returned by xChetos, so provider-side page caps do not skip licenses.
    'provider_page_size' => 100,
    'provider_max_pages' => 250,
    'provider_max_records' => 25000,

    'connect_timeout' => 8,
    'request_timeout' => 20,
    'force_ipv4' => false,
];
