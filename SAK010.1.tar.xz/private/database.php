<?php
// Private configuration for sakazuki.spwz.online.
// Preserve this single file when replacing or updating the shared project.
if (!defined('APP_BASE_URL')) define('APP_BASE_URL', 'https://sakazuki.spwz.online');
if (!defined('TRUEMONEY_PROVIDER_URL')) define('TRUEMONEY_PROVIDER_URL', 'https://truemoneyapi.vercel.app/api/truewallet');

return [
    'site' => [
        'id' => 'sakazuki-010',
        'domain' => 'sakazuki.spwz.online',
        'label' => 'Sakazuki SPWZ',
    ],

    'host' => 'localhost',
    'user' => 'ihu4qqshopxy_010',
    'pass' => 'Aekthai@',
    'name' => 'ihu4qqshopxy_010',

    // Both websites currently use the same real encryption key. The shared
    // key_id says that honestly; the website identity is kept separately above.
    'secrets' => [
        'store_bridge' => [
            'key_id' => 'spwz-shared-store-bridge-v1',
            'encryption_key_b64' => 'oVlru1HDMkZkj6aXLtJRTl5j3Wbque3Gc3vhm/afqlk=',
            'legacy_keys_b64' => [],
        ],
        'recovery_mail' => [
            'key_id' => 'spwz-shared-recovery-mail-v1',
            'master_secret' => '3017da48ce0e8550677d6b913835d302c47d2e911cf9126042f89fec352486e5',
        ],
    ],
];
