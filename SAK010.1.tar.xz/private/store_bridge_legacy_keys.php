<?php
return ['encryption_keys' => ['oVlru1HDMkZkj6aXLtJRTl5j3Wbque3Gc3vhm/afqlk=']];
